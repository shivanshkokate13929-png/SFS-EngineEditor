// ModCode.cs
// Build Engine Editor - Spaceflight Simulator 1.6+ code mod
//
// When an engine or RCS thruster is selected in the build screen, a floating
// "Engine Editor" panel shows its Thrust and Isp and lets you change them.
//
// How it works
//   - Selection comes from the game's own BuildManager selection, so the panel
//     follows whatever the game's Part Editor is showing.
//   - Values are written to the live module and its serialized stat input,
//     then read back to confirm.
//   - Nothing changes until you press Apply.
//
// APIs confirmed from public mods (BuildUpgrade, MalfunctionsMod, the modern template):
//   ModLoader.Mod with Early_Load() and Load(); SFS.Builds.BuildManager.main.buildGrid
//   .GetSelectedParts(); SFS.Parts.Modules.EngineModule; build scene "Build_PC";
//   BuildMenus.OnEmptyClick. Stat members were checked against the local game assembly.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using ModLoader;
using SFS;
using SFS.Builds;
using SFS.Parts;
using SFS.Parts.Modules;
using SFS.World;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace BuildEngineEditor
{
    // ------------------------------------------------------------------
    // Config: every name that is an assumption about SFS internals lives here.
    // Candidates are tried in order; the first match wins. Case-insensitive.
    // ------------------------------------------------------------------
    internal static class Config
    {
        public const string ModNameID = "buildengineeditor";
        public const string SavedThrustVariable = "buildengineeditor_thrust";
        public const string SavedIspVariable = "buildengineeditor_isp";

        // The PC build scene is "Build_PC". Any scene starting with "Build" counts.
        public const string BuildScenePrefix = "Build";

        public const float PollInterval = 0.1f;
        public const float PanelWidth = 340f;
        public const float PanelHeight = 318f;
        public const double MaxStat = 1000000000.0;
        public const double Tolerance = 0.001;

        // SFS 1.6 engine fields are Composed_Float values named "thrust" and "ISP";
        // RCS fields are floats with the same names.
        public static readonly string[] ThrustMemberNames =
            { "thrust" };
        public static readonly string[] IspMemberNames =
            { "ISP", "isp" };
    }

    // ------------------------------------------------------------------
    // Logging. ErrorOnce throttles repeated errors so a broken path cannot flood the log.
    // ------------------------------------------------------------------
    internal static class EELog
    {
        private const string Prefix = "[BuildEngineEditor] ";
        private static readonly Dictionary<string, int> Counts = new Dictionary<string, int>();

        public static void Info(string message)
        {
            UnityEngine.Debug.Log(Prefix + message);
        }

        public static void Warn(string message)
        {
            UnityEngine.Debug.LogWarning(Prefix + message);
        }

        public static void Error(string message)
        {
            UnityEngine.Debug.LogError(Prefix + message);
        }

        public static void ErrorOnce(string key, string message)
        {
            int count;
            Counts.TryGetValue(key, out count);
            count++;
            Counts[key] = count;

            if (count == 1)
            {
                Error(message);
            }
            else if (count % 300 == 0)
            {
                Error(message + " (repeated " + count + " times)");
            }
        }
    }

    // ------------------------------------------------------------------
    // Reflection helpers for numeric members (float or double).
    // Every game-type access that is not verified goes through here.
    // ------------------------------------------------------------------
    internal static class Reflect
    {
        private const BindingFlags Flags =
            BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

        private static readonly Dictionary<string, MemberInfo> Cache = new Dictionary<string, MemberInfo>();

        // Finds the first matching member in candidate order. Accepts float and double
        // members, and reference wrappers (such as Float_Reference) whose Value is numeric.
        public static MemberInfo FindNumeric(Type type, string[] names)
        {
            if (type == null) return null;

            foreach (string name in names)
            {
                MemberInfo member = Find(type, name);
                if (member != null) return member;
            }
            return null;
        }

        public static bool TryReadNumber(object target, MemberInfo member, out double value)
        {
            value = 0.0;
            if (target == null || member == null) return false;

            try
            {
                return Unbox(GetValue(member, target), out value);
            }
            catch (Exception ex)
            {
                EELog.ErrorOnce("read-" + member.Name, "Could not read '" + member.Name + "': " + ex.Message);
                return false;
            }
        }

        public static bool TryWriteNumber(object target, MemberInfo member, double value)
        {
            if (target == null || member == null) return false;

            try
            {
                Type declared = DeclaredType(member);
                if (IsNumeric(declared))
                {
                    return SetValue(member, target, Box(declared, value));
                }

                // Reference wrapper: write through its Value property.
                object wrapper = GetValue(member, target);
                PropertyInfo inner = wrapper == null ? null : WrapperValue(wrapper.GetType());
                if (inner == null) return false;

                FieldInfo input = wrapper.GetType().GetField("input", Flags);
                if (input == null || input.FieldType != typeof(string) || input.IsInitOnly)
                {
                    EELog.ErrorOnce("input-" + member.Name,
                        "Could not update the serialized input for '" + member.Name + "'.");
                    return false;
                }

                object boxed = Box(inner.PropertyType, value);
                double serializedValue = inner.PropertyType == typeof(float)
                    ? (double)(float)boxed
                    : (double)boxed;
                FieldInfo compiled = wrapper.GetType().GetField("compiled", Flags);
                MethodInfo getResult = wrapper.GetType().GetMethod(
                    "GetResult", Flags, null, new[] { typeof(bool) }, null);
                if (compiled == null || getResult == null || compiled.IsInitOnly)
                {
                    EELog.ErrorOnce("compiled-" + member.Name,
                        "Could not refresh the compiled input for '" + member.Name + "'.");
                    return false;
                }

                string previousInput = (string)input.GetValue(wrapper);
                object previousCompiled = compiled.GetValue(wrapper);
                try
                {
                    input.SetValue(wrapper, "#" + serializedValue.ToString("R", CultureInfo.InvariantCulture));

                    // Composed_Float caches its parsed expression; refreshing only Value/input
                    // leaves that cache pointing at the original part default.
                    object refreshed = getResult.Invoke(wrapper, new object[] { true });
                    double refreshedValue;
                    if (!Unbox(refreshed, out refreshedValue) ||
                        Math.Abs(refreshedValue - serializedValue) >
                        0.000001 * Math.Max(1.0, Math.Abs(serializedValue)))
                    {
                        throw new InvalidOperationException(
                            "The updated input did not evaluate to the requested value.");
                    }

                    inner.SetValue(wrapper, Box(inner.PropertyType, refreshedValue), null);
                }
                catch
                {
                    input.SetValue(wrapper, previousInput);
                    compiled.SetValue(wrapper, previousCompiled);
                    throw;
                }
                return true;
            }
            catch (Exception ex)
            {
                EELog.ErrorOnce("write-" + member.Name, "Could not write '" + member.Name + "': " + ex.Message);
                return false;
            }
        }

        private static MemberInfo Find(Type type, string name)
        {
            string key = type.FullName + "|" + name;
            MemberInfo cached;
            if (Cache.TryGetValue(key, out cached)) return cached;

            MemberInfo found = null;

            foreach (FieldInfo field in type.GetFields(Flags))
            {
                if (!SameName(field.Name, name)) continue;
                if (!IsUsable(field.FieldType, field.IsInitOnly)) continue;
                found = field;
                break;
            }

            if (found == null)
            {
                foreach (PropertyInfo prop in type.GetProperties(Flags))
                {
                    if (!SameName(prop.Name, name)) continue;
                    if (!prop.CanRead || !prop.CanWrite) continue;
                    if (!IsUsable(prop.PropertyType, false)) continue;
                    found = prop;
                    break;
                }
            }

            Cache[key] = found;
            return found;
        }

        // A numeric member must be writable. A wrapper is changed through its Value,
        // so a readonly field holding a wrapper is still usable.
        private static bool IsUsable(Type type, bool readOnlyField)
        {
            if (IsNumeric(type)) return !readOnlyField;
            return WrapperValue(type) != null;
        }

        private static PropertyInfo WrapperValue(Type type)
        {
            if (type == null || type.IsValueType) return null;

            foreach (PropertyInfo prop in type.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (prop.Name == "Value" && IsNumeric(prop.PropertyType) && prop.CanRead && prop.CanWrite)
                {
                    return prop;
                }
            }
            return null;
        }

        private static bool Unbox(object raw, out double value)
        {
            value = 0.0;
            if (raw == null) return false;

            if (raw is double)
            {
                value = (double)raw;
                return true;
            }
            if (raw is float)
            {
                value = (float)raw;
                return true;
            }

            PropertyInfo inner = WrapperValue(raw.GetType());
            if (inner == null) return false;

            object innerValue = inner.GetValue(raw, null);
            if (innerValue is double)
            {
                value = (double)innerValue;
                return true;
            }
            if (innerValue is float)
            {
                value = (float)innerValue;
                return true;
            }
            return false;
        }

        private static object GetValue(MemberInfo member, object target)
        {
            FieldInfo field = member as FieldInfo;
            if (field != null) return field.GetValue(target);
            return ((PropertyInfo)member).GetValue(target, null);
        }

        private static bool SetValue(MemberInfo member, object target, object value)
        {
            FieldInfo field = member as FieldInfo;
            if (field != null)
            {
                field.SetValue(target, value);
            }
            else
            {
                ((PropertyInfo)member).SetValue(target, value, null);
            }
            return true;
        }

        private static Type DeclaredType(MemberInfo member)
        {
            FieldInfo field = member as FieldInfo;
            if (field != null) return field.FieldType;
            return ((PropertyInfo)member).PropertyType;
        }

        private static object Box(Type type, double value)
        {
            return type == typeof(float) ? (object)(float)value : (object)value;
        }

        private static bool SameName(string a, string b)
        {
            return string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsNumeric(Type type)
        {
            return type == typeof(float) || type == typeof(double);
        }
    }

    // ------------------------------------------------------------------
    // Data for one editable engine or RCS thruster.
    // ------------------------------------------------------------------
    internal sealed class EngineHandle
    {
        public Part Part;
        public Component Module;
        public string PartName;
        public bool IsRcs;
        public MemberInfo ThrustMember;
        public MemberInfo IspMember;

        public bool IsAlive
        {
            get { return Part != null && Module != null; }
        }

        public string Kind
        {
            get { return IsRcs ? "RCS thruster" : "Engine"; }
        }
    }

    // The first values seen for a module this session. Used by Reset.
    internal sealed class Baseline
    {
        public bool HasThrust;
        public bool HasIsp;
        public double Thrust;
        public double Isp;
    }

    // ------------------------------------------------------------------
    // Finds the engine module on a part and reads or writes its stats.
    // ------------------------------------------------------------------
    internal static class EngineDiscovery
    {
        private static readonly Dictionary<int, Baseline> Baselines = new Dictionary<int, Baseline>();
        private static readonly HashSet<string> LoggedTypes = new HashSet<string>();
        private static readonly HashSet<string> LoggedMissingParts = new HashSet<string>();

        public static bool TryFind(Part part, out EngineHandle handle)
        {
            handle = null;
            if (part == null) return false;

            Component partComponent = part as Component;
            if (partComponent == null)
            {
                EELog.ErrorOnce("part-not-component", "Part is not a Unity Component, so modules cannot be found.");
                return false;
            }

            EngineModule engineModule = First(part.GetModules<EngineModule>());
            RcsModule rcsModule = engineModule == null
                ? First(part.GetModules<RcsModule>())
                : null;
            Component module = engineModule != null ? (Component)engineModule : rcsModule;
            if (module == null)
            {
                string name = partComponent.gameObject.name;
                if (LoggedMissingParts.Add(name))
                {
                    EELog.Info("No engine module on '" + name + "'. Modules present: " + ListModules(partComponent));
                }
                return false;
            }

            Type moduleType = module.GetType();
            handle = new EngineHandle();
            handle.Part = part;
            handle.Module = module;
            handle.PartName = partComponent.gameObject.name;
            handle.IsRcs = rcsModule != null;
            handle.ThrustMember = Reflect.FindNumeric(moduleType, Config.ThrustMemberNames);
            handle.IspMember = Reflect.FindNumeric(moduleType, Config.IspMemberNames);

            CaptureBaseline(handle);

            if (LoggedTypes.Add(moduleType.FullName))
            {
                EELog.Info("Module " + moduleType.FullName +
                           " | Thrust: " + Describe(handle.ThrustMember) +
                           " | Isp: " + Describe(handle.IspMember));
            }
            return true;
        }

        public static bool ReadStat(EngineHandle h, bool thrust, out double value)
        {
            MemberInfo member = thrust ? h.ThrustMember : h.IspMember;
            return Reflect.TryReadNumber(h.Module, member, out value);
        }

        public static bool TryReadVariable(Part part, string key, out double value)
        {
            value = 0.0;
            try
            {
                var variables = part.variablesModule;
                if (variables == null) return false;
                value = variables.doubleVariables.GetValue(key);
                return true;
            }
            catch (Exception)
            {
                // Missing keys are expected while probing, so this stays silent.
                return false;
            }
        }

        // Writes the live stat and its serialized representation, then reads it back.
        public static bool Apply(EngineHandle h, double thrust, double isp, out string summary)
        {
            bool thrustSaved = StorePersistentStat(h.Part, Config.SavedThrustVariable, thrust);
            bool ispSaved = StorePersistentStat(h.Part, Config.SavedIspVariable, isp);
            if (!thrustSaved || !ispSaved)
            {
                summary = "Could not save edited stats with this part.";
                return false;
            }

            bool thrustOk;
            bool ispOk;
            string thrustLine = SyncStat("Thrust", h, true, thrust, out thrustOk);
            string ispLine = SyncStat("Isp", h, false, isp, out ispOk);
            summary = thrustLine + ". " + ispLine + ". Saved with part.";
            return thrustOk && ispOk;
        }

        public static void RestoreSavedStats(PartSave save, Part part)
        {
            if (save == null || part == null || save.NUMBER_VARIABLES == null) return;

            double thrust;
            double isp;
            bool hasThrust = save.NUMBER_VARIABLES.TryGetValue(Config.SavedThrustVariable, out thrust);
            bool hasIsp = save.NUMBER_VARIABLES.TryGetValue(Config.SavedIspVariable, out isp);
            if (!hasThrust && !hasIsp) return;

            EngineHandle handle;
            if (!TryFind(part, out handle))
            {
                EELog.ErrorOnce("restore-module-" + save.name,
                    "Saved engine stats exist for '" + save.name + "', but no engine module was found.");
                return;
            }

            bool thrustOk = !hasThrust ||
                (StorePersistentStat(part, Config.SavedThrustVariable, thrust) &&
                 Reflect.TryWriteNumber(handle.Module, handle.ThrustMember, thrust));
            bool ispOk = !hasIsp ||
                (StorePersistentStat(part, Config.SavedIspVariable, isp) &&
                 Reflect.TryWriteNumber(handle.Module, handle.IspMember, isp));

            if (!thrustOk || !ispOk)
            {
                EELog.ErrorOnce("restore-stats-" + save.name,
                    "Could not restore saved engine stats for '" + save.name + "'.");
                return;
            }

            EELog.Info("Restored saved engine stats for '" + save.name +
                       "': thrust=" + (hasThrust ? thrust.ToString("R", CultureInfo.InvariantCulture) : "unchanged") +
                       ", isp=" + (hasIsp ? isp.ToString("R", CultureInfo.InvariantCulture) : "unchanged") + ".");
        }

        public static Baseline GetBaseline(EngineHandle h)
        {
            Baseline baseline;
            return Baselines.TryGetValue(h.Module.GetInstanceID(), out baseline) ? baseline : null;
        }

        public static string DescribeVariable(Part part, string key)
        {
            if (string.IsNullOrEmpty(key)) return "Type a key first.";

            double value;
            if (!TryReadVariable(part, key, out value))
            {
                return "No readable value under '" + key + "'.";
            }
            return "'" + key + "' = " + value.ToString("R", CultureInfo.InvariantCulture) +
                   " (0 can also mean the key is missing)";
        }

        public static bool Near(double a, double b)
        {
            return Math.Abs(a - b) <= Config.Tolerance * Math.Max(1.0, Math.Abs(b));
        }

        public static string Describe(MemberInfo member)
        {
            return member == null ? "NOT FOUND" : "saved/live '" + member.Name + "'";
        }

        private static void CaptureBaseline(EngineHandle h)
        {
            int id = h.Module.GetInstanceID();
            if (Baselines.ContainsKey(id)) return;

            Baseline baseline = new Baseline();
            double value;
            if (ReadStat(h, true, out value))
            {
                baseline.HasThrust = true;
                baseline.Thrust = value;
            }
            if (ReadStat(h, false, out value))
            {
                baseline.HasIsp = true;
                baseline.Isp = value;
            }
            Baselines[id] = baseline;
        }

        private static string SyncStat(string label, EngineHandle h, bool thrust, double value, out bool ok)
        {
            MemberInfo member = thrust ? h.ThrustMember : h.IspMember;
            if (member == null)
            {
                ok = false;
                return label + " not found on this part";
            }

            double live;
            ok = Reflect.TryWriteNumber(h.Module, member, value) &&
                 Reflect.TryReadNumber(h.Module, member, out live) &&
                 Near(live, value);
            return label + ": saved/live " + (ok ? "ok" : "MISMATCH");
        }

        private static bool StorePersistentStat(Part part, string key, double value)
        {
            if (part == null || part.variablesModule == null || part.variablesModule.doubleVariables == null)
            {
                EELog.ErrorOnce("save-variable-" + key,
                    "Could not store '" + key + "': the part has no numeric variable list.");
                return false;
            }

            try
            {
                part.variablesModule.doubleVariables.SetValue(
                    key, value, new ValueTuple<bool, bool>(true, true));

                double stored = part.variablesModule.doubleVariables.GetValue(key);
                if (!Near(stored, value))
                {
                    EELog.ErrorOnce("save-readback-" + key,
                        "Could not verify the saved value for '" + key + "'.");
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                EELog.ErrorOnce("save-variable-" + key,
                    "Could not store '" + key + "': " + ex.Message);
                return false;
            }
        }

        private static T First<T>(T[] components) where T : Component
        {
            return components == null || components.Length == 0 ? null : components[0];
        }

        private static string ListModules(Component partComponent)
        {
            var names = new List<string>();
            foreach (Component c in partComponent.GetComponentsInChildren<Component>(true))
            {
                if (c == null || c is Transform) continue;
                names.Add(c.GetType().Name);
            }
            return names.Count == 0 ? "(none)" : string.Join(", ", names);
        }
    }

    // ------------------------------------------------------------------
    // The game's own selection, read every poll.
    // ------------------------------------------------------------------
    internal static class BuildSelection
    {
        public static Part[] GetSelected()
        {
            try
            {
                BuildManager manager = BuildManager.main;
                if (manager == null || manager.buildGrid == null) return null;
                return manager.buildGrid.GetSelectedParts();
            }
            catch (Exception ex)
            {
                EELog.ErrorOnce("selection", "Could not read the build selection: " + ex.Message);
                return null;
            }
        }
    }

    // ------------------------------------------------------------------
    // Scene behaviour: polls selection and draws the floating panel.
    // ------------------------------------------------------------------
    public sealed class EngineEditorBehaviour : MonoBehaviour
    {
        // True while the mouse is over the panel. Read by the BuildMenus patch
        // so a click on the panel does not deselect the part.
        public static bool PointerOverPanel;

        private EngineHandle handle;
        private int selectedEngines;
        private int lastSignature;
        private bool hasSignature;
        private bool panelVisible;
        private bool positioned;
        private int windowId;
        private Rect windowRect = new Rect(0f, 0f, Config.PanelWidth, Config.PanelHeight);
        private GUIStyle windowStyle;
        private GUIStyle cardStyle;
        private GUIStyle headingStyle;
        private GUIStyle partNameStyle;
        private GUIStyle fieldLabelStyle;
        private GUIStyle mutedStyle;
        private GUIStyle statusStyle;
        private GUIStyle textFieldStyle;
        private GUIStyle primaryButtonStyle;
        private GUIStyle buttonStyle;
        private GUIStyle toggleStyle;
        private Texture2D windowTexture;
        private Texture2D cardTexture;
        private Texture2D fieldTexture;
        private Texture2D buttonTexture;
        private Texture2D buttonHoverTexture;
        private Texture2D primaryTexture;
        private Texture2D primaryHoverTexture;
        private string lastSceneName = string.Empty;
        private float nextPoll;

        private string thrustText = string.Empty;
        private string ispText = string.Empty;
        private string status = string.Empty;
        private bool showAdvanced;
        private string probeKey = string.Empty;
        private string probeResult = string.Empty;

        private void Update()
        {
            try
            {
                string scene = SceneManager.GetActiveScene().name;
                if (scene != lastSceneName)
                {
                    lastSceneName = scene;
                    EELog.Info("Scene: " + scene);
                    hasSignature = false;
                    Close();
                }

                if (!IsBuildScene(scene)) return;
                if (UnityEngine.Time.unscaledTime < nextPoll) return;
                nextPoll = UnityEngine.Time.unscaledTime + Config.PollInterval;

                PollSelection();
            }
            catch (Exception ex)
            {
                EELog.ErrorOnce("update", "Update error: " + ex);
            }
        }

        private void OnGUI()
        {
            PointerOverPanel = false;

            try
            {
                if (!panelVisible || handle == null) return;
                if (!handle.IsAlive)
                {
                    Close();
                    return;
                }

                EnsureStyles();
                windowRect.height = showAdvanced
                    ? (string.IsNullOrEmpty(status) ? 426f : 452f)
                    : (string.IsNullOrEmpty(status) ? Config.PanelHeight : Config.PanelHeight + 24f);
                ClampToScreen();
                Vector2 mouse = UnityEngine.Event.current.mousePosition;
                if (windowId == 0) windowId = GUIUtility.GetControlID(FocusType.Passive);
                windowRect = GUI.Window(windowId, windowRect, DrawWindow, "ENGINE EDITOR", windowStyle);
                PointerOverPanel = windowRect.Contains(mouse);
            }
            catch (Exception ex)
            {
                EELog.ErrorOnce("ongui", "Panel error: " + ex);
            }
        }

        private static bool IsBuildScene(string sceneName)
        {
            return !string.IsNullOrEmpty(sceneName) &&
                   sceneName.StartsWith(Config.BuildScenePrefix, StringComparison.OrdinalIgnoreCase);
        }

        private void PollSelection()
        {
            Part[] selected = BuildSelection.GetSelected();
            if (selected == null || selected.Length == 0)
            {
                hasSignature = false;
                Close();
                return;
            }

            // The selection has not changed since the last poll, so there is nothing new to do.
            int signature = Signature(selected);
            if (hasSignature && signature == lastSignature)
            {
                if (handle != null && !handle.IsAlive) Close();
                return;
            }
            hasSignature = true;
            lastSignature = signature;

            EngineHandle found = null;
            int engines = 0;
            foreach (Part part in selected)
            {
                EngineHandle candidate;
                if (part != null && EngineDiscovery.TryFind(part, out candidate))
                {
                    engines++;
                    if (found == null) found = candidate;
                }
            }

            if (found == null)
            {
                Close();
                return;
            }
            Open(found, engines);
        }

        private static int Signature(Part[] parts)
        {
            unchecked
            {
                int hash = 17;
                foreach (Part part in parts)
                {
                    hash = hash * 31 + (part == null ? 0 : RuntimeHelpers.GetHashCode(part));
                }
                return hash;
            }
        }

        private void Open(EngineHandle h, int engines)
        {
            handle = h;
            selectedEngines = engines;
            panelVisible = true;
            status = string.Empty;
            probeResult = string.Empty;

            if (!positioned)
            {
                // Top right of the build screen: clear of the rocket and the centre of the grid.
                windowRect.x = UnityEngine.Screen.width - Config.PanelWidth - 20f;
                windowRect.y = 90f;
                positioned = true;
            }

            RefreshFieldsFromLive();

            var notes = new List<string>();
            CheckSource(notes, "Thrust", h.ThrustMember);
            CheckSource(notes, "Isp", h.IspMember);
            status = string.Join(" ", notes);
        }

        private void Close()
        {
            panelVisible = false;
            handle = null;
        }

        private void RefreshFieldsFromLive()
        {
            double value;
            thrustText = EngineDiscovery.ReadStat(handle, true, out value) ? ToText(value) : string.Empty;
            ispText = EngineDiscovery.ReadStat(handle, false, out value) ? ToText(value) : string.Empty;
        }

        private static void CheckSource(List<string> notes, string label, MemberInfo member)
        {
            if (member == null)
            {
                notes.Add(label + " was not found on this module.");
            }
        }

        private void Apply()
        {
            if (handle == null) return;

            double thrust;
            double isp;
            if (!TryParse(thrustText, out thrust))
            {
                status = "Thrust must be a number.";
                return;
            }
            if (!TryParse(ispText, out isp))
            {
                status = "Isp must be a number.";
                return;
            }
            if (thrust <= 0.0 || isp <= 0.0 || thrust > Config.MaxStat || isp > Config.MaxStat)
            {
                status = "Enter values above 0 and up to 1,000,000,000.";
                return;
            }

            string summary;
            bool ok = EngineDiscovery.Apply(handle, thrust, isp, out summary);
            status = (ok ? "Applied. " : "Partly applied. ") + summary;
            EELog.Info(handle.PartName + ": thrust=" + thrust + ", isp=" + isp + " -> " + summary);

            RefreshFieldsFromLive();
        }

        private void ResetToBaseline()
        {
            if (handle == null) return;

            Baseline baseline = EngineDiscovery.GetBaseline(handle);
            if (baseline == null || (!baseline.HasThrust && !baseline.HasIsp))
            {
                status = "No baseline recorded for this part.";
                return;
            }

            if (baseline.HasThrust) thrustText = ToText(baseline.Thrust);
            if (baseline.HasIsp) ispText = ToText(baseline.Isp);
            Apply();
        }

        private void DrawWindow(int id)
        {
            if (handle == null) return;

            GUILayout.BeginVertical(cardStyle);
            GUILayout.Label(handle.Kind.ToUpperInvariant(), headingStyle);
            GUILayout.Label(handle.PartName, partNameStyle);
            if (selectedEngines > 1)
            {
                GUILayout.Label(selectedEngines + " selected - editing the first.", mutedStyle);
            }
            GUILayout.EndVertical();
            GUILayout.Space(8f);

            GUILayout.BeginVertical(cardStyle);
            GUILayout.BeginHorizontal();
            GUILayout.Label("THRUST", fieldLabelStyle, GUILayout.Width(88f));
            thrustText = GUILayout.TextField(thrustText, textFieldStyle, GUILayout.MinWidth(120f));
            GUILayout.Label("t", mutedStyle, GUILayout.Width(14f));
            GUILayout.EndHorizontal();

            GUILayout.Space(5f);
            GUILayout.BeginHorizontal();
            GUILayout.Label("SPECIFIC IMPULSE", fieldLabelStyle, GUILayout.Width(128f));
            ispText = GUILayout.TextField(ispText, textFieldStyle, GUILayout.MinWidth(80f));
            GUILayout.Label("s", mutedStyle, GUILayout.Width(14f));
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();

            GUILayout.Space(8f);
            if (!string.IsNullOrEmpty(status))
            {
                GUILayout.Label(status, statusStyle);
            }

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("APPLY", primaryButtonStyle, GUILayout.Height(30f))) Apply();
            if (GUILayout.Button("RESET", buttonStyle, GUILayout.Height(30f))) ResetToBaseline();
            GUILayout.EndHorizontal();

            GUILayout.BeginVertical(cardStyle);
            showAdvanced = GUILayout.Toggle(showAdvanced, "Advanced details", toggleStyle);
            if (showAdvanced)
            {
                GUILayout.Space(4f);
                GUILayout.Label("Thrust source: " + EngineDiscovery.Describe(handle.ThrustMember), mutedStyle);
                GUILayout.Label("Impulse source: " + EngineDiscovery.Describe(handle.IspMember), mutedStyle);
                GUILayout.BeginHorizontal();
                GUILayout.Label("Variable key", fieldLabelStyle, GUILayout.Width(88f));
                probeKey = GUILayout.TextField(probeKey, textFieldStyle, GUILayout.MinWidth(100f));
                if (GUILayout.Button("READ", buttonStyle, GUILayout.Width(54f), GUILayout.Height(26f)))
                {
                    probeResult = EngineDiscovery.DescribeVariable(handle.Part, probeKey);
                }
                GUILayout.EndHorizontal();

                if (!string.IsNullOrEmpty(probeResult))
                {
                    GUILayout.Label(probeResult, mutedStyle);
                }
            }
            GUILayout.EndVertical();

            GUI.DragWindow(new Rect(0f, 0f, 10000f, 22f));
        }

        private void EnsureStyles()
        {
            if (windowStyle != null) return;

            Color panel = new Color(0.075f, 0.13f, 0.22f, 0.98f);
            Color card = new Color(0.10f, 0.19f, 0.31f, 1f);
            Color field = new Color(0.055f, 0.11f, 0.19f, 1f);
            Color button = new Color(0.13f, 0.24f, 0.38f, 1f);
            Color buttonHover = new Color(0.18f, 0.32f, 0.49f, 1f);
            Color primary = new Color(0.12f, 0.38f, 0.66f, 1f);
            Color primaryHover = new Color(0.17f, 0.48f, 0.79f, 1f);

            windowTexture = CreateRoundedTexture(panel, new Color(0.30f, 0.49f, 0.70f, 1f));
            cardTexture = CreateRoundedTexture(card, new Color(0.17f, 0.29f, 0.43f, 1f));
            fieldTexture = CreateRoundedTexture(field, new Color(0.22f, 0.34f, 0.48f, 1f));
            buttonTexture = CreateRoundedTexture(button, new Color(0.25f, 0.38f, 0.53f, 1f));
            buttonHoverTexture = CreateRoundedTexture(buttonHover, new Color(0.40f, 0.58f, 0.76f, 1f));
            primaryTexture = CreateRoundedTexture(primary, new Color(0.36f, 0.62f, 0.88f, 1f));
            primaryHoverTexture = CreateRoundedTexture(primaryHover, new Color(0.52f, 0.73f, 0.95f, 1f));

            windowStyle = new GUIStyle(GUI.skin.window);
            windowStyle.normal.background = windowTexture;
            windowStyle.onNormal.background = windowTexture;
            windowStyle.border = new RectOffset(12, 12, 14, 12);
            windowStyle.padding = new RectOffset(12, 12, 28, 12);
            windowStyle.alignment = TextAnchor.UpperCenter;
            windowStyle.fontSize = 14;
            windowStyle.fontStyle = FontStyle.Bold;
            windowStyle.normal.textColor = new Color(0.91f, 0.95f, 1f);

            cardStyle = new GUIStyle(GUI.skin.box);
            cardStyle.normal.background = cardTexture;
            cardStyle.border = new RectOffset(10, 10, 10, 10);
            cardStyle.padding = new RectOffset(10, 10, 8, 8);
            cardStyle.margin = new RectOffset(0, 0, 0, 0);

            headingStyle = new GUIStyle(GUI.skin.label);
            headingStyle.fontSize = 10;
            headingStyle.fontStyle = FontStyle.Bold;
            headingStyle.normal.textColor = new Color(0.62f, 0.77f, 0.92f);

            partNameStyle = new GUIStyle(GUI.skin.label);
            partNameStyle.fontSize = 16;
            partNameStyle.fontStyle = FontStyle.Bold;
            partNameStyle.wordWrap = true;
            partNameStyle.normal.textColor = Color.white;

            fieldLabelStyle = new GUIStyle(GUI.skin.label);
            fieldLabelStyle.fontSize = 11;
            fieldLabelStyle.fontStyle = FontStyle.Bold;
            fieldLabelStyle.normal.textColor = new Color(0.80f, 0.88f, 0.97f);

            mutedStyle = new GUIStyle(GUI.skin.label);
            mutedStyle.fontSize = 11;
            mutedStyle.wordWrap = true;
            mutedStyle.normal.textColor = new Color(0.69f, 0.78f, 0.88f);

            statusStyle = new GUIStyle(mutedStyle);
            statusStyle.normal.textColor = new Color(0.86f, 0.80f, 0.63f);

            textFieldStyle = new GUIStyle(GUI.skin.textField);
            textFieldStyle.normal.background = fieldTexture;
            textFieldStyle.hover.background = fieldTexture;
            textFieldStyle.focused.background = fieldTexture;
            textFieldStyle.border = new RectOffset(8, 8, 6, 6);
            textFieldStyle.padding = new RectOffset(8, 8, 4, 4);
            textFieldStyle.normal.textColor = Color.white;
            textFieldStyle.focused.textColor = Color.white;
            textFieldStyle.fontSize = 13;

            buttonStyle = CreateButtonStyle(buttonTexture, buttonHoverTexture);
            primaryButtonStyle = CreateButtonStyle(primaryTexture, primaryHoverTexture);
            toggleStyle = new GUIStyle(GUI.skin.toggle);
            toggleStyle.fontSize = 11;
            toggleStyle.normal.textColor = new Color(0.80f, 0.88f, 0.97f);
            toggleStyle.onNormal.textColor = Color.white;
        }

        private static GUIStyle CreateButtonStyle(Texture2D normal, Texture2D hover)
        {
            GUIStyle style = new GUIStyle(GUI.skin.button);
            style.normal.background = normal;
            style.hover.background = hover;
            style.active.background = hover;
            style.border = new RectOffset(8, 8, 7, 7);
            style.fontSize = 11;
            style.fontStyle = FontStyle.Bold;
            style.normal.textColor = Color.white;
            style.hover.textColor = Color.white;
            style.active.textColor = Color.white;
            return style;
        }

        private static Texture2D CreateRoundedTexture(Color fill, Color outline)
        {
            const int size = 32;
            const float radius = 7f;
            const float border = 1.5f;
            Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.name = "BuildEngineEditor UI";
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.filterMode = FilterMode.Bilinear;

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float px = Mathf.Abs(x + 0.5f - size * 0.5f) - (size * 0.5f - radius);
                    float py = Mathf.Abs(y + 0.5f - size * 0.5f) - (size * 0.5f - radius);
                    float outside = Mathf.Sqrt(Mathf.Max(px, 0f) * Mathf.Max(px, 0f) +
                                               Mathf.Max(py, 0f) * Mathf.Max(py, 0f)) +
                                    Mathf.Min(Mathf.Max(px, py), 0f) - radius;
                    if (outside >= 0f)
                    {
                        texture.SetPixel(x, y, Color.clear);
                    }
                    else
                    {
                        float inner = outside + border;
                        Color pixel = inner < 0f ? fill : outline;
                        pixel.a *= Mathf.Clamp01(-outside);
                        texture.SetPixel(x, y, pixel);
                    }
                }
            }

            texture.Apply();
            return texture;
        }

        private void ClampToScreen()
        {
            windowRect.x = Mathf.Clamp(windowRect.x, 0f, Mathf.Max(0f, UnityEngine.Screen.width - windowRect.width));
            windowRect.y = Mathf.Clamp(windowRect.y, 0f, Mathf.Max(0f, UnityEngine.Screen.height - windowRect.height));
        }

        private static string ToText(double value)
        {
            return value.ToString("R", CultureInfo.InvariantCulture);
        }

        // Accepts "." or "," as the decimal separator.
        private static bool TryParse(string text, out double value)
        {
            value = 0.0;
            if (string.IsNullOrEmpty(text)) return false;

            string normalized = text.Trim().Replace(',', '.');
            if (!double.TryParse(normalized, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
            {
                return false;
            }
            return !double.IsNaN(value) && !double.IsInfinity(value);
        }
    }

    // ------------------------------------------------------------------
    // Keeps the build grid from clearing the selection when you click the panel.
    // ------------------------------------------------------------------
    public static class BuildMenus_OnEmptyClick_Patch
    {
        public static bool Prefix()
        {
            return !EngineEditorBehaviour.PointerOverPanel;
        }
    }

    public static class PartsLoader_CreatePart_Patch
    {
        public static void Postfix(PartSave __0, Part __result)
        {
            try
            {
                EngineDiscovery.RestoreSavedStats(__0, __result);
            }
            catch (Exception ex)
            {
                EELog.ErrorOnce("restore-patch", "Could not restore saved stats after creating a part: " + ex);
            }
        }
    }

    internal static class HarmonyPatchInstaller
    {
        private static bool installed;

        public static void InstallBuildMenusPatch()
        {
            if (installed) return;

            Type harmonyType = FindHarmonyType("HarmonyLib.Harmony");
            Type harmonyMethodType = FindHarmonyType("HarmonyLib.HarmonyMethod");
            if (harmonyType == null || harmonyMethodType == null)
            {
                throw new InvalidOperationException(
                    "Harmony was not found in the mod loader. The editor can load, but panel clicks may clear the selection.");
            }

            ConstructorInfo harmonyConstructor = harmonyType.GetConstructor(new[] { typeof(string) });
            ConstructorInfo harmonyMethodConstructor =
                harmonyMethodType.GetConstructor(new[] { typeof(MethodInfo) });
            MethodInfo target = typeof(BuildMenus).GetMethod(
                "OnEmptyClick", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            MethodInfo prefix = typeof(BuildMenus_OnEmptyClick_Patch).GetMethod(
                "Prefix", BindingFlags.Public | BindingFlags.Static);
            MethodInfo restoreTarget = FindPartSaveCreateMethod();
            MethodInfo restorePostfix = typeof(PartsLoader_CreatePart_Patch).GetMethod(
                "Postfix", BindingFlags.Public | BindingFlags.Static);

            MethodInfo patch = null;
            foreach (MethodInfo candidate in harmonyType.GetMethods(BindingFlags.Public | BindingFlags.Instance))
            {
                if (candidate.Name != "Patch") continue;
                ParameterInfo[] parameters = candidate.GetParameters();
                if (parameters.Length == 5 &&
                    parameters[0].ParameterType == typeof(MethodBase) &&
                    parameters[1].ParameterType == harmonyMethodType)
                {
                    patch = candidate;
                    break;
                }
            }

            if (harmonyConstructor == null || harmonyMethodConstructor == null ||
                target == null || prefix == null || restoreTarget == null ||
                restorePostfix == null || patch == null)
            {
                throw new MissingMethodException(
                    "The loaded game or Harmony version does not expose the expected patch APIs.");
            }

            object harmony = harmonyConstructor.Invoke(new object[] { Config.ModNameID });
            object harmonyPrefix = harmonyMethodConstructor.Invoke(new object[] { prefix });
            patch.Invoke(harmony, new object[] { target, harmonyPrefix, null, null, null });
            object restoreHarmonyPostfix = harmonyMethodConstructor.Invoke(new object[] { restorePostfix });
            patch.Invoke(harmony, new object[] { restoreTarget, null, restoreHarmonyPostfix, null, null });
            installed = true;
            EELog.Info("Installed build selection and part-stat persistence patches.");
        }

        private static MethodInfo FindPartSaveCreateMethod()
        {
            const BindingFlags flags =
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
            foreach (MethodInfo method in typeof(PartsLoader).GetMethods(flags))
            {
                if (method.Name != "CreatePart") continue;
                ParameterInfo[] parameters = method.GetParameters();
                if (parameters.Length == 5 &&
                    parameters[0].ParameterType == typeof(PartSave) &&
                    parameters[1].ParameterType == typeof(Transform) &&
                    parameters[2].ParameterType == typeof(string) &&
                    parameters[4].ParameterType == typeof(OwnershipState).MakeByRefType())
                {
                    return method;
                }
            }
            return null;
        }

        private static Type FindHarmonyType(string fullName)
        {
            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type type = assembly.GetType(fullName, false);
                if (type != null) return type;
            }

            try
            {
                return Assembly.Load(new AssemblyName("0Harmony")).GetType(fullName, false);
            }
            catch (FileNotFoundException)
            {
                return null;
            }
        }
    }

    // ------------------------------------------------------------------
    // Mod entry point. The loader calls Early_Load() and Load().
    // ------------------------------------------------------------------
    public class ModCode : Mod
    {
        public static ModCode Instance { get; private set; }

        private static GameObject host;

        public ModCode()
        {
            Instance = this;
        }

        public override string ModNameID => Config.ModNameID;
        public override string DisplayName => "Build Engine Editor";
        public override string Author => "SFS Mod Build";
        public override string MinimumGameVersionNecessary => "1.6.0";
        public override string ModVersion => "1.0.0";
        public override string Description => "Edit engine Thrust and Isp from the build screen.";

        public override Dictionary<string, string> Dependencies => new Dictionary<string, string>();

        public override void Early_Load()
        {
            try
            {
                HarmonyPatchInstaller.InstallBuildMenusPatch();
            }
            catch (Exception ex)
            {
                EELog.Error("Harmony patching failed: " + ex);
            }
        }

        public override void Load()
        {
            try
            {
                if (host != null) return;

                host = new GameObject("BuildEngineEditor");
                UnityEngine.Object.DontDestroyOnLoad(host);
                host.AddComponent<EngineEditorBehaviour>();

                EELog.Info("Loaded. Select an engine in the build screen to open the editor.");
            }
            catch (Exception ex)
            {
                EELog.Error("Load failed: " + ex);
            }
        }
    }
}